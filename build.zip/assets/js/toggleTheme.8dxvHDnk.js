import{e}from"./exampleThemeStorage.9aDuBHYs.js";async function o(){console.log("initial theme!",await e.get()),await e.toggle(),console.log("toggled theme",await e.get())}o();
